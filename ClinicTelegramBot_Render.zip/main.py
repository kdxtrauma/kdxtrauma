import asyncio
import logging
import os
from datetime import datetime
from telegram import Update, ReplyKeyboardRemove, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, CommandHandler, ContextTypes, MessageHandler,
    ConversationHandler, filters
)
from docxtpl import DocxTemplate

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

(FIO, BIRTHDATE, PASSPORT, KEM_VYDAN, DATE_VYDACHI, ADDRESS, PHONE, EMAIL) = range(8)

counter_path = "counter.txt"
def get_contract_number():
    if not os.path.exists(counter_path):
        with open(counter_path, "w") as f:
            f.write("1")
            return 1
    with open(counter_path, "r+") as f:
        num = int(f.read().strip())
        f.seek(0)
        f.write(str(num + 1))
        return num

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Здравствуйте! Давайте оформим ваши документы.\n\nПожалуйста, укажите ваше полное ФИО:")
    return FIO

async def get_fio(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['fio'] = update.message.text
    await update.message.reply_text("Дата рождения (например, 01.01.1980):")
    return BIRTHDATE

async def get_birth(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['birthdate'] = update.message.text
    await update.message.reply_text("Серия и номер паспорта:")
    return PASSPORT

async def get_passport(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['passport'] = update.message.text
    await update.message.reply_text("Кем выдан паспорт:")
    return KEM_VYDAN

async def get_kem_vydan(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['kem_vydan'] = update.message.text
    await update.message.reply_text("Дата выдачи паспорта:")
    return DATE_VYDACHI

async def get_date_vydachi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['date_vydachi'] = update.message.text
    await update.message.reply_text("Адрес регистрации:")
    return ADDRESS

async def get_address(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['address'] = update.message.text
    await update.message.reply_text("Телефон:")
    return PHONE

async def get_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['phone'] = update.message.text
    await update.message.reply_text("Email:")
    return EMAIL

async def get_email(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['email'] = update.message.text

    tpl = DocxTemplate("Объединенный_документ_медуслуг.docx")
    contract_num = get_contract_number()
    today = datetime.today().strftime("%d.%m.%Y")

    context_data = {
        'НомерДоговора': contract_num,
        'Дата': today,
        'ФИО': context.user_data['fio'],
        'ДатаРождения': context.user_data['birthdate'],
        'Паспорт': context.user_data['passport'],
        'КемВыдан': context.user_data['kem_vydan'],
        'ДатаВыдачи': context.user_data['date_vydachi'],
        'Адрес': context.user_data['address'],
        'Телефон': context.user_data['phone'],
        'Email': context.user_data['email']
    }

    tpl.render(context_data)
    filepath = f"contract_{contract_num}.docx"
    tpl.save(filepath)

    await update.message.reply_document(document=open(filepath, 'rb'), filename=filepath)
    await update.message.reply_text(
        "Документ успешно сформирован! Вы можете подписаться на наш канал по ссылке ниже:",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📢 Подписаться на канал", url="https://t.me/kdxtrauma")]
        ])
    )
    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Операция отменена.", reply_markup=ReplyKeyboardRemove())
    return ConversationHandler.END

async def main():
    import nest_asyncio
    nest_asyncio.apply()
    app = ApplicationBuilder().token("7711160606:AAFUSDpyuoi93gYzlwOX9xqfhyK-nFE4CEE").build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states={
            FIO: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_fio)],
            BIRTHDATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_birth)],
            PASSPORT: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_passport)],
            KEM_VYDAN: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_kem_vydan)],
            DATE_VYDACHI: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_date_vydachi)],
            ADDRESS: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_address)],
            PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_phone)],
            EMAIL: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_email)],
        },
        fallbacks=[CommandHandler('cancel', cancel)]
    )

    app.add_handler(conv_handler)
    await app.run_polling()

if __name__ == '__main__':
    asyncio.run(main())
